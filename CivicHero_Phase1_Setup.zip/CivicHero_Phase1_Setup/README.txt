CIVICHERO PHASE 1
=================

1. Extract this folder anywhere, for example:
   C:\CivicHeroPhase1

2. Open PowerShell and run:

   powershell -ExecutionPolicy Bypass -File "C:\CivicHeroPhase1\apply-phase1.ps1" -ProjectRoot "C:\CivicHeroSolution"

3. Start backend:

   cd C:\CivicHeroSolution\backend\CivicHero.Backend
   dotnet run --launch-profile http

4. Start frontend in a second PowerShell window:

   cd C:\CivicHeroSolution\frontend\civichero-web
   npm run dev

5. Open:
   http://localhost:5173
   http://localhost:5180/swagger
   http://localhost:5180/api/v1/health

The script backs up every replaced Phase 1 file under:
C:\CivicHeroSolution\.phase-backups\
