param(
    [string]$ProjectRoot = "C:\CivicHeroSolution",
    [switch]$SkipBuild
)

$ErrorActionPreference = "Stop"

$ProjectRoot = [System.IO.Path]::GetFullPath($ProjectRoot)
$SourceRoot = Join-Path $PSScriptRoot "phase1-files"

if (-not (Test-Path $SourceRoot)) {
    throw "Phase 1 files were not found at: $SourceRoot"
}

$backendProject = Join-Path $ProjectRoot "backend\CivicHero.Backend\CivicHero.Backend.csproj"
$frontendPackage = Join-Path $ProjectRoot "frontend\civichero-web\package.json"

if (-not (Test-Path $backendProject)) {
    throw "Invalid project folder. Missing: $backendProject"
}

if (-not (Test-Path $frontendPackage)) {
    throw "Invalid project folder. Missing: $frontendPackage"
}

$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupRoot = Join-Path $ProjectRoot ".phase-backups\phase1-$timestamp"

Write-Host ""
Write-Host "Applying CivicHero Phase 1" -ForegroundColor Cyan
Write-Host "Project: $ProjectRoot"
Write-Host "Backup:  $backupRoot"
Write-Host ""

$sourceFiles = Get-ChildItem -Path $SourceRoot -Recurse -File

foreach ($sourceFile in $sourceFiles) {
    $relativePath = $sourceFile.FullName.Substring($SourceRoot.Length).TrimStart('\', '/')
    $destination = Join-Path $ProjectRoot $relativePath
    $destinationDirectory = Split-Path $destination -Parent

    New-Item -ItemType Directory -Path $destinationDirectory -Force | Out-Null

    if (Test-Path $destination) {
        $backupDestination = Join-Path $backupRoot $relativePath
        $backupDirectory = Split-Path $backupDestination -Parent
        New-Item -ItemType Directory -Path $backupDirectory -Force | Out-Null
        Copy-Item $destination $backupDestination -Force
    }

    Copy-Item $sourceFile.FullName $destination -Force
    Write-Host "UPDATED $relativePath" -ForegroundColor Green
}

Write-Host ""
Write-Host "Phase 1 files applied successfully." -ForegroundColor Green

if (-not $SkipBuild) {
    Write-Host ""
    Write-Host "Building backend..." -ForegroundColor Cyan
    Push-Location (Join-Path $ProjectRoot "backend\CivicHero.Backend")
    try {
        dotnet restore
        if ($LASTEXITCODE -ne 0) { throw "dotnet restore failed." }

        dotnet build --no-restore
        if ($LASTEXITCODE -ne 0) { throw "dotnet build failed." }
    }
    finally {
        Pop-Location
    }

    Write-Host ""
    Write-Host "Building frontend..." -ForegroundColor Cyan
    Push-Location (Join-Path $ProjectRoot "frontend\civichero-web")
    try {
        npm install
        if ($LASTEXITCODE -ne 0) { throw "npm install failed." }

        npm run build
        if ($LASTEXITCODE -ne 0) { throw "npm run build failed." }
    }
    finally {
        Pop-Location
    }

    Write-Host ""
    Write-Host "Backend and frontend builds passed." -ForegroundColor Green
}

Write-Host ""
Write-Host "Start backend:" -ForegroundColor Yellow
Write-Host "  cd C:\CivicHeroSolution\backend\CivicHero.Backend"
Write-Host "  dotnet run --launch-profile http"
Write-Host ""
Write-Host "Start frontend in another PowerShell window:" -ForegroundColor Yellow
Write-Host "  cd C:\CivicHeroSolution\frontend\civichero-web"
Write-Host "  npm run dev"
Write-Host ""
Write-Host "Open http://localhost:5173"
